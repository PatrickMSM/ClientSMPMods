mainMenu {
    enabled = true
    label {
        position {
            x { it - 2 }
            y { it - 20 }
        }
        text = literal("Fabulously Optimized 3.1.0-beta.2")
        align = "right"
        color = 0xFFFFFF
        hoveredColor = 0x55FFFF
        shadow = true
        onClicked = url("https://www.curseforge.com/minecraft/modpacks/fabulously-optimized")
    }
}